/**
 * Rentify – Cloudflare Worker + D1
 * API + static assets (public/)
 */

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, X-Auth-Token',
      'Access-Control-Allow-Methods': 'GET,POST,PATCH,PUT,DELETE,OPTIONS',
      ...extra,
    },
  });
}

function maskName(name) {
  if (!name || name.length < 2) return name || '•••';
  return name.trim().split(/\s+/).map((part) => {
    if (part.length <= 2) return part[0] + '•';
    return part.split('').map((c, i) => (i === 0 || (i > 0 && i % 3 === 0) ? c : '•')).join('');
  }).join(' ');
}

function calcCustomerPrice(ownerRate, commissionPct) {
  return ownerRate + Math.round(ownerRate * (commissionPct / 100));
}

function addDays(dateStr, n) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

function uid() {
  return crypto.randomUUID();
}

async function hasOverlap(db, machineId, start, end, excludeBookingId = null) {
  let sql = `SELECT id FROM availability WHERE machine_id = ? AND start_date < ? AND end_date > ?`;
  const params = [machineId, end, start];
  if (excludeBookingId) {
    sql += ` AND (booking_id IS NULL OR booking_id != ?)`;
    params.push(excludeBookingId);
  }
  const row = await db.prepare(sql).bind(...params).first();
  return !!row;
}

async function getSession(db, token) {
  if (!token) return null;
  const row = await db.prepare('SELECT * FROM sessions WHERE token = ?').bind(token).first();
  if (!row) return null;
  if (row.expires_at && row.expires_at < new Date().toISOString()) {
    await db.prepare('DELETE FROM sessions WHERE token = ?').bind(token).run();
    return null;
  }
  return {
    id: row.user_id,
    role: row.role,
    full_name: row.full_name,
    email: row.email,
    company_name: row.company_name,
    is_premium: !!row.is_premium,
  };
}

async function audit(db, actor, action, entityType, entityId, prev, nextVal) {
  await db.prepare(
    `INSERT INTO audit_logs (id, actor_id, actor_role, action, entity_type, entity_id, previous_value, new_value)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    uid(),
    actor?.id || null,
    actor?.role || null,
    action,
    entityType,
    entityId,
    prev != null ? JSON.stringify(prev) : null,
    nextVal != null ? JSON.stringify(nextVal) : null
  ).run();
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    if (method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type, X-Auth-Token',
          'Access-Control-Allow-Methods': 'GET,POST,PATCH,PUT,DELETE,OPTIONS',
        },
      });
    }

    const db = env.DB;
    if (!db && path.startsWith('/api')) {
      return json({ error: 'D1 database not bound. Set database_id in wrangler.toml' }, 500);
    }

    try {
      // ========== AUTH ==========
      if (path === '/api/auth/login' && method === 'POST') {
        const body = await request.json();
        const user = await db.prepare('SELECT * FROM users WHERE email = ?').bind(body.email).first();
        if (!user || user.password_hash !== body.password) {
          return json({ error: 'Invalid email or password' }, 401);
        }
        if (user.is_suspended) return json({ error: 'Account suspended' }, 403);
        const token = uid();
        const expires = new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString();
        await db.prepare(
          `INSERT INTO sessions (token, user_id, role, full_name, email, company_name, is_premium, expires_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        ).bind(token, user.id, user.role, user.full_name, user.email, user.company_name, user.is_premium, expires).run();
        return json({
          token,
          user: {
            id: user.id,
            role: user.role,
            full_name: user.full_name,
            email: user.email,
            company_name: user.company_name,
            is_premium: !!user.is_premium,
            city: user.city,
          },
        });
      }

      if (path === '/api/auth/register' && method === 'POST') {
        const body = await request.json();
        if (!['OWNER', 'RENTER'].includes(body.role)) return json({ error: 'Invalid role' }, 400);
        const exists = await db.prepare('SELECT id FROM users WHERE email = ?').bind(body.email).first();
        if (exists) return json({ error: 'Email already registered' }, 400);
        const id = uid();
        await db.prepare(
          `INSERT INTO users (id, role, full_name, email, phone, password_hash, company_name, city, state, pin_code, verification_status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Unverified')`
        ).bind(id, body.role, body.full_name, body.email, body.phone || null, body.password, body.company_name || null, body.city || null, body.state || null, body.pin_code || null).run();
        const token = uid();
        const expires = new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString();
        await db.prepare(
          `INSERT INTO sessions (token, user_id, role, full_name, email, company_name, is_premium, expires_at)
           VALUES (?, ?, ?, ?, ?, ?, 0, ?)`
        ).bind(token, id, body.role, body.full_name, body.email, body.company_name || null, expires).run();
        return json({ token, user: { id, role: body.role, full_name: body.full_name, email: body.email, company_name: body.company_name, is_premium: false } });
      }

      if (path === '/api/auth/me' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user) return json({ error: 'Unauthorized' }, 401);
        const row = await db.prepare(
          'SELECT id, role, full_name, email, phone, company_name, city, state, is_premium, verification_status, reliability_score FROM users WHERE id = ?'
        ).bind(user.id).first();
        return json(row);
      }

      if (path === '/api/demo-accounts' && method === 'GET') {
        return json({
          admin: { email: 'admin@rentify.in', password: 'admin123' },
          owner: { email: 'rajesh@pavaki.in', password: 'owner123' },
          renter: { email: 'priya@abcinfra.in', password: 'renter123' },
        });
      }

      if (path === '/api/categories' && method === 'GET') {
        const { results } = await db.prepare('SELECT * FROM categories ORDER BY name').all();
        return json(results || []);
      }

      // ========== SEARCH ==========
      if (path === '/api/machines/search' && method === 'GET') {
        const q = url.searchParams.get('q') || '';
        const duration = parseInt(url.searchParams.get('days') || '1', 10);
        let start = url.searchParams.get('start_date') || new Date().toISOString().slice(0, 10);
        const end = addDays(start, duration - 1);
        const city = url.searchParams.get('city');
        const sort = url.searchParams.get('sort') || 'recommended';

        let sql = `
          SELECT m.*, c.name as category_name, u.company_name, u.reliability_score as owner_reliability,
            (SELECT public_url FROM machine_media WHERE machine_id = m.id AND is_approved = 1 AND is_primary = 1 LIMIT 1) as photo
          FROM machines m
          LEFT JOIN categories c ON c.id = m.category_id
          LEFT JOIN users u ON u.id = m.owner_id
          WHERE m.status = 'APPROVED' AND u.is_suspended = 0
        `;
        const params = [];
        if (q) {
          sql += ` AND (m.name LIKE ? OR m.brand LIKE ? OR m.model LIKE ? OR c.name LIKE ?)`;
          const like = `%${q}%`;
          params.push(like, like, like, like);
        }
        if (city) {
          sql += ` AND m.city LIKE ?`;
          params.push(`%${city}%`);
        }
        sql += ` ORDER BY m.condition_score DESC, u.reliability_score DESC`;

        const { results: rows } = await db.prepare(sql).bind(...params).all();
        const results = [];

        for (const m of rows || []) {
          const conflict = await hasOverlap(db, m.id, start, end);
          let nextAvailable = null;
          let bookedUntil = null;

          if (conflict || m.operational_status === 'RENTED' || m.operational_status === 'MAINTENANCE') {
            const { results: blocks } = await db.prepare(
              `SELECT start_date, end_date, status FROM availability WHERE machine_id = ? AND end_date >= ? ORDER BY start_date`
            ).bind(m.id, start).all();
            if (blocks?.length) {
              bookedUntil = blocks[0].end_date;
              let cursor = start;
              for (const b of blocks) {
                if (b.start_date > cursor) {
                  nextAvailable = cursor;
                  break;
                }
                if (b.end_date >= cursor) cursor = addDays(b.end_date, 1);
              }
              if (!nextAvailable) nextAvailable = cursor;
            } else if (m.operational_status === 'AVAILABLE') {
              nextAvailable = start;
            }
          } else {
            nextAvailable = start;
          }

          const isAvailableForPeriod = !conflict && m.operational_status === 'AVAILABLE';
          results.push({
            id: m.id,
            name: m.name,
            brand: m.brand,
            model: m.model,
            category: m.category_name,
            customer_price_daily: m.customer_price_daily,
            condition_score: m.condition_score,
            rating_avg: Math.round((m.rating_avg || 0) * 10) / 10,
            rating_count: m.rating_count,
            city: m.city,
            state: m.state,
            operator_available: !!m.operator_available,
            transport_available: !!m.transport_available,
            photo: m.photo,
            masked_owner: maskName(m.company_name),
            owner_reliability: m.owner_reliability,
            operational_status: m.operational_status,
            available_for_period: isAvailableForPeriod,
            booked_until: bookedUntil,
            next_available: nextAvailable,
            can_prebook: !isAvailableForPeriod && nextAvailable && nextAvailable <= end,
            requested_start: start,
            requested_end: end,
            duration_days: duration,
            afi_protected: true,
          });
        }

        if (sort === 'price_asc') results.sort((a, b) => a.customer_price_daily - b.customer_price_daily);
        else if (sort === 'price_desc') results.sort((a, b) => b.customer_price_daily - a.customer_price_daily);
        else if (sort === 'rating') results.sort((a, b) => b.rating_avg - a.rating_avg);
        else if (sort === 'reliability') results.sort((a, b) => b.owner_reliability - a.owner_reliability);

        return json({ query: { q, days: duration, start_date: start, end_date: end }, count: results.length, machines: results });
      }

      // Machine detail
      const machineMatch = path.match(/^\/api\/machines\/([^/]+)$/);
      if (machineMatch && method === 'GET' && !path.includes('search')) {
        const id = machineMatch[1];
        if (id === 'search') return json({ error: 'Not found' }, 404);
        const m = await db.prepare(`
          SELECT m.*, c.name as category_name, u.company_name, u.reliability_score as owner_reliability
          FROM machines m
          LEFT JOIN categories c ON c.id = m.category_id
          LEFT JOIN users u ON u.id = m.owner_id
          WHERE m.id = ? AND m.status = 'APPROVED'
        `).bind(id).first();
        if (!m) return json({ error: 'Machine not found' }, 404);
        const { results: media } = await db.prepare(
          `SELECT id, type, public_url, is_primary FROM machine_media WHERE machine_id = ? AND is_approved = 1`
        ).bind(m.id).all();
        const { results: availability } = await db.prepare(
          `SELECT start_date, end_date, status FROM availability WHERE machine_id = ? AND end_date >= date('now') ORDER BY start_date LIMIT 20`
        ).bind(m.id).all();
        const daily = m.customer_price_daily;
        return json({
          id: m.id,
          name: m.name,
          brand: m.brand,
          model: m.model,
          manufacturing_year: m.manufacturing_year,
          category: m.category_name,
          public_description: m.public_description,
          customer_price_daily: daily,
          packages: [
            { label: '1 Day', days: 1, price: daily },
            { label: '3 Days', days: 3, price: Math.round(daily * 3 * 0.95) },
            { label: '7 Days', days: 7, price: Math.round(daily * 7 * 0.90) },
            { label: '15 Days', days: 15, price: Math.round(daily * 15 * 0.85) },
            { label: '30 Days', days: 30, price: Math.round(daily * 30 * 0.80) },
          ],
          condition_score: m.condition_score,
          rating_avg: Math.round((m.rating_avg || 0) * 10) / 10,
          rating_count: m.rating_count,
          city: m.city,
          state: m.state,
          operator_available: !!m.operator_available,
          transport_available: !!m.transport_available,
          specs: JSON.parse(m.specs_json || '{}'),
          media: media || [],
          availability: availability || [],
          masked_owner: maskName(m.company_name),
          owner_reliability: m.owner_reliability,
          operational_status: m.operational_status,
          afi_protected: true,
        });
      }

      // ========== BOOKINGS ==========
      if (path === '/api/bookings' && method === 'POST') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'RENTER') return json({ error: 'Unauthorized' }, 401);
        const body = await request.json();
        const duration = parseInt(body.duration_days || 1, 10);
        const start = body.start_date;
        const end = addDays(start, duration - 1);
        const machine = await db.prepare(
          `SELECT m.* FROM machines m WHERE m.id = ? AND m.status = 'APPROVED'`
        ).bind(body.machine_id).first();
        if (!machine) return json({ error: 'Machine not found' }, 404);
        if (await hasOverlap(db, body.machine_id, start, end)) {
          return json({ error: 'Machine not available for selected dates' }, 409);
        }
        const ownerRate = machine.owner_rate_daily;
        const commission = Math.round(ownerRate * (machine.platform_commission_pct / 100) * duration);
        const customerDaily = machine.customer_price_daily;
        const customerTotal = customerDaily * duration;
        const ownerPayable = ownerRate * duration;
        const bookingId = uid();
        await db.prepare(`
          INSERT INTO bookings (id, machine_id, renter_id, start_date, end_date, duration_days,
            owner_rate, commission_amount, customer_price, total_amount, owner_payable, status, is_prebook)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'CONFIRMED', ?)
        `).bind(bookingId, body.machine_id, user.id, start, end, duration, ownerRate, commission, customerDaily, customerTotal, ownerPayable, body.is_prebook ? 1 : 0).run();
        await db.prepare(
          `INSERT INTO availability (id, machine_id, start_date, end_date, status, source, booking_id) VALUES (?, ?, ?, ?, 'BOOKED', 'platform', ?)`
        ).bind(uid(), body.machine_id, start, end, bookingId).run();
        const today = new Date().toISOString().slice(0, 10);
        if (start <= today && end >= today) {
          await db.prepare(`UPDATE machines SET operational_status = 'RENTED', updated_at = datetime('now') WHERE id = ?`).bind(body.machine_id).run();
        }
        await audit(db, user, 'BOOKING_CREATED', 'booking', bookingId, null, { machine_id: body.machine_id, start, end, total: customerTotal });
        return json({
          success: true,
          booking_id: bookingId,
          total_amount: customerTotal,
          customer_price_daily: customerDaily,
          start_date: start,
          end_date: end,
          afi_protected: true,
          message: 'Booking confirmed. AFI Protected.',
        });
      }

      if (path === '/api/bookings/my' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user) return json({ error: 'Unauthorized' }, 401);
        if (user.role === 'RENTER') {
          const { results } = await db.prepare(`
            SELECT b.*, m.name as machine_name, m.brand, m.model, m.city,
              (SELECT public_url FROM machine_media WHERE machine_id = m.id AND is_approved = 1 LIMIT 1) as photo,
              u.company_name as owner_company
            FROM bookings b
            JOIN machines m ON m.id = b.machine_id
            JOIN users u ON u.id = m.owner_id
            WHERE b.renter_id = ?
            ORDER BY b.created_at DESC
          `).bind(user.id).all();
          return json((results || []).map((r) => ({
            ...r,
            masked_owner: r.identity_revealed ? r.owner_company : maskName(r.owner_company),
            owner_company: undefined,
            owner_rate: undefined,
            commission_amount: undefined,
            owner_payable: undefined,
          })));
        }
        if (user.role === 'OWNER') {
          const { results } = await db.prepare(`
            SELECT b.*, m.name as machine_name, m.brand, m.model,
              u.company_name as renter_company, u.full_name as renter_name
            FROM bookings b
            JOIN machines m ON m.id = b.machine_id
            JOIN users u ON u.id = b.renter_id
            WHERE m.owner_id = ?
            ORDER BY b.created_at DESC
          `).bind(user.id).all();
          return json((results || []).map((r) => ({
            ...r,
            masked_renter: r.identity_revealed ? r.renter_company : maskName(r.renter_company),
            renter_company: r.identity_revealed ? r.renter_company : undefined,
            renter_name: r.identity_revealed ? r.renter_name : undefined,
            customer_price: undefined,
            total_amount: undefined,
          })));
        }
        return json({ error: 'Forbidden' }, 403);
      }

      // ========== OWNER ==========
      if (path === '/api/owner/machines' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'OWNER') return json({ error: 'Unauthorized' }, 401);
        const { results } = await db.prepare(`
          SELECT m.*, c.name as category_name,
            (SELECT public_url FROM machine_media WHERE machine_id = m.id AND is_primary = 1 LIMIT 1) as photo
          FROM machines m
          LEFT JOIN categories c ON c.id = m.category_id
          WHERE m.owner_id = ?
          ORDER BY m.created_at DESC
        `).bind(user.id).all();
        return json(results || []);
      }

      if (path === '/api/owner/machines' && method === 'POST') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'OWNER') return json({ error: 'Unauthorized' }, 401);
        const body = await request.json();
        if (!body.name || !body.owner_rate_daily) return json({ error: 'Name and rate required' }, 400);
        const settings = await db.prepare("SELECT value FROM settings WHERE key = 'default_commission_pct'").first();
        const commPct = parseFloat(settings?.value || env.DEFAULT_COMMISSION_PCT || 15);
        const customerPrice = calcCustomerPrice(body.owner_rate_daily, commPct);
        const id = uid();
        await db.prepare(`
          INSERT INTO machines (
            id, owner_id, category_id, name, brand, model, manufacturing_year,
            description, public_description, owner_rate_daily, platform_commission_pct,
            customer_price_daily, status, operational_status, city, state,
            operator_available, transport_available, specs_json
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', 'AVAILABLE', ?, ?, ?, ?, ?)
        `).bind(
          id, user.id, body.category_id || null, body.name, body.brand || null, body.model || null,
          body.manufacturing_year || null, body.description || null, body.description || null,
          body.owner_rate_daily, commPct, customerPrice, body.city || null, body.state || null,
          body.operator_available ? 1 : 0, body.transport_available ? 1 : 0,
          JSON.stringify(body.specs || {})
        ).run();
        await audit(db, user, 'MACHINE_CREATED', 'machine', id, null, { name: body.name });
        return json({ success: true, id, status: 'PENDING', message: 'Machine submitted for admin approval' });
      }

      const ownerStatusMatch = path.match(/^\/api\/owner\/machines\/([^/]+)\/status$/);
      if (ownerStatusMatch && method === 'PATCH') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'OWNER') return json({ error: 'Unauthorized' }, 401);
        const machine = await db.prepare('SELECT * FROM machines WHERE id = ? AND owner_id = ?').bind(ownerStatusMatch[1], user.id).first();
        if (!machine) return json({ error: 'Not found' }, 404);
        const body = await request.json();
        if (!['AVAILABLE', 'RENTED', 'MAINTENANCE'].includes(body.operational_status)) {
          return json({ error: 'Invalid status' }, 400);
        }
        if (body.operational_status === 'AVAILABLE') {
          const today = new Date().toISOString().slice(0, 10);
          const active = await db.prepare(
            `SELECT id, end_date FROM availability WHERE machine_id = ? AND status = 'BOOKED' AND start_date <= ? AND end_date >= ?`
          ).bind(machine.id, today, today).first();
          if (active) {
            return json({ error: `Machine has an active booking until ${active.end_date}. Complete return first.` }, 409);
          }
        }
        await db.prepare(`UPDATE machines SET operational_status = ?, updated_at = datetime('now') WHERE id = ?`)
          .bind(body.operational_status, machine.id).run();
        await audit(db, user, 'STATUS_CHANGE', 'machine', machine.id, machine.operational_status, body.operational_status);
        return json({ success: true, operational_status: body.operational_status });
      }

      const returnMatch = path.match(/^\/api\/owner\/bookings\/([^/]+)\/return$/);
      if (returnMatch && method === 'POST') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'OWNER') return json({ error: 'Unauthorized' }, 401);
        const booking = await db.prepare(`
          SELECT b.* FROM bookings b JOIN machines m ON m.id = b.machine_id WHERE b.id = ? AND m.owner_id = ?
        `).bind(returnMatch[1], user.id).first();
        if (!booking) return json({ error: 'Not found' }, 404);
        const body = await request.json();
        if (body.returned) {
          await db.prepare(`UPDATE bookings SET status = 'COMPLETED', updated_at = datetime('now') WHERE id = ?`).bind(booking.id).run();
          const newStatus = body.needs_maintenance ? 'MAINTENANCE' : 'AVAILABLE';
          await db.prepare(`UPDATE machines SET operational_status = ?, updated_at = datetime('now') WHERE id = ?`)
            .bind(newStatus, booking.machine_id).run();
          await audit(db, user, 'RETURN_CONFIRMED', 'booking', booking.id, null, { needs_maintenance: body.needs_maintenance });
          return json({ success: true, machine_status: newStatus });
        }
        return json({ success: true });
      }

      // ========== ADMIN ==========
      if (path === '/api/admin/dashboard' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const total_machines = (await db.prepare('SELECT COUNT(*) as c FROM machines').first()).c;
        const available = (await db.prepare("SELECT COUNT(*) as c FROM machines WHERE operational_status = 'AVAILABLE' AND status = 'APPROVED'").first()).c;
        const rented = (await db.prepare("SELECT COUNT(*) as c FROM machines WHERE operational_status = 'RENTED'").first()).c;
        const maintenance = (await db.prepare("SELECT COUNT(*) as c FROM machines WHERE operational_status = 'MAINTENANCE'").first()).c;
        const pending_approval = (await db.prepare("SELECT COUNT(*) as c FROM machines WHERE status = 'PENDING'").first()).c;
        const total_owners = (await db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'OWNER'").first()).c;
        const total_renters = (await db.prepare("SELECT COUNT(*) as c FROM users WHERE role = 'RENTER'").first()).c;
        const active_bookings = (await db.prepare("SELECT COUNT(*) as c FROM bookings WHERE status IN ('CONFIRMED','ACTIVE')").first()).c;
        const revenue = (await db.prepare("SELECT COALESCE(SUM(commission_amount),0) as s FROM bookings WHERE status NOT IN ('CANCELLED')").first()).s;
        return json({ total_machines, available, rented, maintenance, pending_approval, total_owners, total_renters, active_bookings, revenue, disputes: 0 });
      }

      if (path === '/api/admin/machines' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const status = url.searchParams.get('status');
        const q = url.searchParams.get('q');
        let sql = `
          SELECT m.*, c.name as category_name, u.full_name as owner_name, u.company_name as owner_company, u.email as owner_email, u.phone as owner_phone
          FROM machines m
          LEFT JOIN categories c ON c.id = m.category_id
          LEFT JOIN users u ON u.id = m.owner_id WHERE 1=1
        `;
        const params = [];
        if (status) { sql += ' AND m.status = ?'; params.push(status); }
        if (q) {
          sql += ' AND (m.name LIKE ? OR u.company_name LIKE ? OR u.full_name LIKE ?)';
          const like = `%${q}%`;
          params.push(like, like, like);
        }
        sql += ' ORDER BY m.created_at DESC';
        const { results } = await db.prepare(sql).bind(...params).all();
        return json(results || []);
      }

      const adminMachineMatch = path.match(/^\/api\/admin\/machines\/([^/]+)$/);
      if (adminMachineMatch && method === 'PATCH') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const machine = await db.prepare('SELECT * FROM machines WHERE id = ?').bind(adminMachineMatch[1]).first();
        if (!machine) return json({ error: 'Not found' }, 404);
        const body = await request.json();
        const updates = [];
        const params = [];
        if (body.status !== undefined) {
          updates.push('status = ?');
          params.push(body.status);
          if (body.status === 'APPROVED') {
            await db.prepare(
              `UPDATE machine_media SET is_approved = 1, public_url = COALESCE(public_url, original_url) WHERE machine_id = ?`
            ).bind(machine.id).run();
            if (!machine.public_description && machine.description) {
              updates.push('public_description = ?');
              params.push(machine.description);
            }
          }
        }
        if (body.operational_status !== undefined) { updates.push('operational_status = ?'); params.push(body.operational_status); }
        if (body.customer_price_daily !== undefined) { updates.push('customer_price_daily = ?'); params.push(body.customer_price_daily); }
        if (body.platform_commission_pct !== undefined) {
          updates.push('platform_commission_pct = ?');
          params.push(body.platform_commission_pct);
          if (body.customer_price_daily === undefined) {
            updates.push('customer_price_daily = ?');
            params.push(calcCustomerPrice(machine.owner_rate_daily, body.platform_commission_pct));
          }
        }
        if (body.public_description !== undefined) { updates.push('public_description = ?'); params.push(body.public_description); }
        if (body.condition_score !== undefined) { updates.push('condition_score = ?'); params.push(body.condition_score); }
        if (!updates.length) return json({ error: 'No updates' }, 400);
        updates.push("updated_at = datetime('now')");
        params.push(machine.id);
        await db.prepare(`UPDATE machines SET ${updates.join(', ')} WHERE id = ?`).bind(...params).run();
        const updated = await db.prepare('SELECT * FROM machines WHERE id = ?').bind(machine.id).first();
        await audit(db, user, 'ADMIN_MACHINE_UPDATE', 'machine', machine.id, { status: machine.status, customer_price_daily: machine.customer_price_daily }, body);
        return json({ success: true, machine: updated });
      }

      if (path === '/api/admin/owners' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const { results } = await db.prepare(`
          SELECT u.*,
            (SELECT COUNT(*) FROM machines WHERE owner_id = u.id) as machine_count,
            (SELECT COUNT(*) FROM bookings b JOIN machines m ON m.id = b.machine_id WHERE m.owner_id = u.id) as booking_count
          FROM users u WHERE u.role = 'OWNER' ORDER BY u.created_at DESC
        `).all();
        return json(results || []);
      }

      if (path === '/api/admin/renters' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const { results } = await db.prepare(`
          SELECT u.*, (SELECT COUNT(*) FROM bookings WHERE renter_id = u.id) as booking_count
          FROM users u WHERE u.role = 'RENTER' ORDER BY u.created_at DESC
        `).all();
        return json(results || []);
      }

      if (path === '/api/admin/bookings' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const { results } = await db.prepare(`
          SELECT b.*, m.name as machine_name, m.brand, m.model,
            o.full_name as owner_name, o.company_name as owner_company,
            r.full_name as renter_name, r.company_name as renter_company
          FROM bookings b
          JOIN machines m ON m.id = b.machine_id
          JOIN users o ON o.id = m.owner_id
          JOIN users r ON r.id = b.renter_id
          ORDER BY b.created_at DESC
        `).all();
        return json(results || []);
      }

      const adminUserMatch = path.match(/^\/api\/admin\/users\/([^/]+)$/);
      if (adminUserMatch && method === 'PATCH') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const body = await request.json();
        const updates = [];
        const params = [];
        if (body.verification_status !== undefined) { updates.push('verification_status = ?'); params.push(body.verification_status); }
        if (body.is_suspended !== undefined) { updates.push('is_suspended = ?'); params.push(body.is_suspended ? 1 : 0); }
        if (body.is_premium !== undefined) { updates.push('is_premium = ?'); params.push(body.is_premium ? 1 : 0); }
        if (body.reliability_score !== undefined) { updates.push('reliability_score = ?'); params.push(body.reliability_score); }
        if (!updates.length) return json({ error: 'No updates' }, 400);
        params.push(adminUserMatch[1]);
        await db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).bind(...params).run();
        await audit(db, user, 'ADMIN_USER_UPDATE', 'user', adminUserMatch[1], null, body);
        return json({ success: true });
      }

      if (path === '/api/admin/audit' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const { results } = await db.prepare(`
          SELECT a.*, u.full_name as actor_name FROM audit_logs a
          LEFT JOIN users u ON u.id = a.actor_id
          ORDER BY a.created_at DESC LIMIT 100
        `).all();
        return json(results || []);
      }

      if (path === '/api/admin/settings' && method === 'GET') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const { results } = await db.prepare('SELECT * FROM settings').all();
        const obj = {};
        (results || []).forEach((r) => { obj[r.key] = r.value; });
        return json(obj);
      }

      if (path === '/api/admin/settings' && method === 'PATCH') {
        const user = await getSession(db, request.headers.get('X-Auth-Token'));
        if (!user || user.role !== 'ADMIN') return json({ error: 'Unauthorized' }, 401);
        const body = await request.json();
        for (const [k, v] of Object.entries(body)) {
          await db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').bind(k, String(v)).run();
        }
        await audit(db, user, 'SETTINGS_UPDATE', 'settings', null, null, body);
        return json({ success: true });
      }

      // Static assets via ASSETS binding (Workers static assets)
      if (env.ASSETS) {
        if (path.startsWith('/admin')) {
          const adminUrl = new URL('/admin/index.html', url.origin);
          return env.ASSETS.fetch(new Request(adminUrl, request));
        }
        if (path === '/' || path === '') {
          return env.ASSETS.fetch(new Request(new URL('/index.html', url.origin), request));
        }
        const assetRes = await env.ASSETS.fetch(request);
        if (assetRes.status !== 404) return assetRes;
        // SPA fallback
        return env.ASSETS.fetch(new Request(new URL('/index.html', url.origin), request));
      }

      return json({ error: 'Not found', path }, 404);
    } catch (err) {
      console.error(err);
      return json({ error: err.message || 'Server error' }, 500);
    }
  },
};
