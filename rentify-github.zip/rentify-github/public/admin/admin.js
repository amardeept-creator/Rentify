let token = localStorage.getItem('rentify_token');
let user = JSON.parse(localStorage.getItem('rentify_user') || 'null');

function headers() {
  const h = { 'Content-Type': 'application/json' };
  if (token) h['X-Auth-Token'] = token;
  return h;
}

async function api(path, opts = {}) {
  const res = await fetch(path, { ...opts, headers: { ...headers(), ...opts.headers } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function fmtINR(n) {
  return '₹' + Number(n).toLocaleString('en-IN');
}

function requireAdmin() {
  if (!user || user.role !== 'ADMIN') {
    alert('Admin login required. Use admin@rentify.in / admin123 on the main app, or login below.');
    // allow login from admin
    const email = prompt('Admin email:', 'admin@rentify.in');
    const password = prompt('Password:', 'admin123');
    if (!email) { window.location.href = '/'; return false; }
    return fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    }).then(r => r.json()).then(data => {
      if (data.error) { alert(data.error); window.location.href = '/'; return false; }
      if (data.user.role !== 'ADMIN') { alert('Not an admin account'); window.location.href = '/'; return false; }
      token = data.token;
      user = data.user;
      localStorage.setItem('rentify_token', token);
      localStorage.setItem('rentify_user', JSON.stringify(user));
      document.getElementById('admin-user-name').textContent = user.full_name;
      return true;
    });
  }
  document.getElementById('admin-user-name').textContent = user.full_name;
  return Promise.resolve(true);
}

function adminLogout() {
  localStorage.removeItem('rentify_token');
  localStorage.removeItem('rentify_user');
  window.location.href = '/';
}

function showAdmin(page) {
  document.querySelectorAll('.admin-page').forEach(p => p.classList.add('hidden'));
  document.getElementById('admin-' + page).classList.remove('hidden');
  document.querySelectorAll('.admin-nav').forEach(b => {
    b.classList.toggle('bg-slate-800', b.dataset.page === page);
  });
  const titles = {
    dashboard: 'Dashboard',
    machines: 'Machine Management',
    owners: 'Owners',
    renters: 'Renters',
    bookings: 'Bookings',
    audit: 'Audit Logs',
    settings: 'Settings',
  };
  document.getElementById('admin-title').textContent = titles[page] || page;

  if (page === 'dashboard') loadDashboard();
  if (page === 'machines') loadMachines();
  if (page === 'owners') loadOwners();
  if (page === 'renters') loadRenters();
  if (page === 'bookings') loadBookings();
  if (page === 'audit') loadAudit();
  if (page === 'settings') loadSettings();
}

async function loadDashboard() {
  try {
    const s = await api('/api/admin/dashboard');
    document.getElementById('stat-cards').innerHTML = [
      { label: 'Total Machines', value: s.total_machines, color: 'bg-blue-50 text-blue-700' },
      { label: 'Available', value: s.available, color: 'bg-emerald-50 text-emerald-700' },
      { label: 'Rented', value: s.rented, color: 'bg-red-50 text-red-700' },
      { label: 'Maintenance', value: s.maintenance, color: 'bg-amber-50 text-amber-700' },
      { label: 'Pending Approval', value: s.pending_approval, color: 'bg-purple-50 text-purple-700' },
      { label: 'Owners', value: s.total_owners, color: 'bg-slate-50 text-slate-700' },
      { label: 'Renters', value: s.total_renters, color: 'bg-slate-50 text-slate-700' },
      { label: 'Active Bookings', value: s.active_bookings, color: 'bg-indigo-50 text-indigo-700' },
      { label: 'Platform Revenue', value: fmtINR(s.revenue), color: 'bg-teal-50 text-teal-700' },
    ].map(c => `
      <div class="rounded-xl p-4 ${c.color} border border-slate-100">
        <div class="text-2xl font-extrabold">${c.value}</div>
        <div class="text-xs font-medium mt-1 opacity-80">${c.label}</div>
      </div>
    `).join('');
  } catch (e) {
    console.error(e);
  }
}

async function loadMachines() {
  const q = document.getElementById('machine-q')?.value || '';
  const status = document.getElementById('machine-status-filter')?.value || '';
  const params = new URLSearchParams();
  if (q) params.set('q', q);
  if (status) params.set('status', status);
  try {
    const rows = await api('/api/admin/machines?' + params);
    document.getElementById('machines-table').innerHTML = `
      <table class="w-full text-sm">
        <thead class="bg-slate-50 text-left text-xs text-slate-500 uppercase">
          <tr>
            <th class="px-4 py-3">Machine</th>
            <th class="px-4 py-3">Owner</th>
            <th class="px-4 py-3">Owner Rate</th>
            <th class="px-4 py-3">Customer Price</th>
            <th class="px-4 py-3">Listing</th>
            <th class="px-4 py-3">Ops Status</th>
            <th class="px-4 py-3">Actions</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100">
          ${rows.map(m => `
            <tr class="hover:bg-slate-50">
              <td class="px-4 py-3">
                <div class="font-semibold">${m.name}</div>
                <div class="text-xs text-slate-500">${m.brand || ''} ${m.model || ''} · ${m.city || ''}</div>
              </td>
              <td class="px-4 py-3">
                <div class="font-medium">${m.owner_name}</div>
                <div class="text-xs text-slate-500">${m.owner_company}</div>
              </td>
              <td class="px-4 py-3 font-mono text-xs">${fmtINR(m.owner_rate_daily)}</td>
              <td class="px-4 py-3 font-bold text-brand-700">${fmtINR(m.customer_price_daily)}</td>
              <td class="px-4 py-3">
                <span class="px-2 py-0.5 rounded-full text-xs font-semibold
                  ${m.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' :
                    m.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                    m.status === 'SUSPENDED' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-600'}">${m.status}</span>
              </td>
              <td class="px-4 py-3 text-xs font-medium">${m.operational_status}</td>
              <td class="px-4 py-3">
                <button onclick='openEditMachine(${JSON.stringify(m).replace(/'/g, "&#39;")})' class="text-brand-600 hover:underline font-semibold text-xs">Edit</button>
                ${m.status === 'PENDING' ? `
                  <button onclick="quickApprove('${m.id}')" class="ml-2 text-emerald-600 hover:underline font-semibold text-xs">Approve</button>
                ` : ''}
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      ${!rows.length ? '<p class="p-6 text-slate-500 text-center">No machines found</p>' : ''}
    `;
  } catch (e) {
    document.getElementById('machines-table').innerHTML = `<p class="p-4 text-red-600">${e.message}</p>`;
  }
}

function openEditMachine(m) {
  document.getElementById('em-id').value = m.id;
  document.getElementById('em-status').value = m.status;
  document.getElementById('em-op-status').value = m.operational_status;
  document.getElementById('em-owner-rate').value = m.owner_rate_daily;
  document.getElementById('em-commission').value = m.platform_commission_pct;
  document.getElementById('em-customer-price').value = m.customer_price_daily;
  document.getElementById('em-public-desc').value = m.public_description || m.description || '';
  document.getElementById('em-condition').value = m.condition_score;
  document.getElementById('edit-modal').classList.remove('hidden');
}

function closeEditModal() {
  document.getElementById('edit-modal').classList.add('hidden');
}

async function saveMachineEdit() {
  const id = document.getElementById('em-id').value;
  const body = {
    status: document.getElementById('em-status').value,
    operational_status: document.getElementById('em-op-status').value,
    platform_commission_pct: parseFloat(document.getElementById('em-commission').value),
    customer_price_daily: parseFloat(document.getElementById('em-customer-price').value),
    public_description: document.getElementById('em-public-desc').value,
    condition_score: parseFloat(document.getElementById('em-condition').value),
  };
  try {
    await api('/api/admin/machines/' + id, { method: 'PATCH', body: JSON.stringify(body) });
    closeEditModal();
    loadMachines();
    alert('✅ Saved. Changes are live on the main application.');
  } catch (e) {
    alert(e.message);
  }
}

async function quickApprove(id) {
  try {
    await api('/api/admin/machines/' + id, {
      method: 'PATCH',
      body: JSON.stringify({ status: 'APPROVED' }),
    });
    loadMachines();
    alert('Machine approved and now visible on main app.');
  } catch (e) {
    alert(e.message);
  }
}

async function loadOwners() {
  try {
    const rows = await api('/api/admin/owners');
    document.getElementById('owners-table').innerHTML = `
      <table class="w-full text-sm">
        <thead class="bg-slate-50 text-left text-xs text-slate-500 uppercase">
          <tr>
            <th class="px-4 py-3">Owner</th>
            <th class="px-4 py-3">Company</th>
            <th class="px-4 py-3">Contact</th>
            <th class="px-4 py-3">Verification</th>
            <th class="px-4 py-3">Machines</th>
            <th class="px-4 py-3">Reliability</th>
            <th class="px-4 py-3">Actions</th>
          </tr>
        </thead>
        <tbody class="divide-y">
          ${rows.map(u => `
            <tr>
              <td class="px-4 py-3 font-medium">${u.full_name}</td>
              <td class="px-4 py-3">${u.company_name || '—'}</td>
              <td class="px-4 py-3 text-xs">${u.email}<br>${u.phone || ''}</td>
              <td class="px-4 py-3 text-xs">${u.verification_status}</td>
              <td class="px-4 py-3">${u.machine_count}</td>
              <td class="px-4 py-3">${u.reliability_score}</td>
              <td class="px-4 py-3">
                ${u.is_suspended
                  ? `<button onclick="toggleSuspend('${u.id}', false)" class="text-emerald-600 text-xs font-semibold">Unsuspend</button>`
                  : `<button onclick="toggleSuspend('${u.id}', true)" class="text-red-600 text-xs font-semibold">Suspend</button>`
                }
                ${!u.is_premium ? `<button onclick="setPremium('${u.id}', true)" class="ml-2 text-brand-600 text-xs font-semibold">Make Premium</button>` : '<span class="text-xs text-amber-600 ml-2">Premium</span>'}
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (e) {
    document.getElementById('owners-table').innerHTML = `<p class="p-4 text-red-600">${e.message}</p>`;
  }
}

async function loadRenters() {
  try {
    const rows = await api('/api/admin/renters');
    document.getElementById('renters-table').innerHTML = `
      <table class="w-full text-sm">
        <thead class="bg-slate-50 text-left text-xs text-slate-500 uppercase">
          <tr>
            <th class="px-4 py-3">Renter</th>
            <th class="px-4 py-3">Company</th>
            <th class="px-4 py-3">Contact</th>
            <th class="px-4 py-3">Verification</th>
            <th class="px-4 py-3">Bookings</th>
            <th class="px-4 py-3">Actions</th>
          </tr>
        </thead>
        <tbody class="divide-y">
          ${rows.map(u => `
            <tr>
              <td class="px-4 py-3 font-medium">${u.full_name}</td>
              <td class="px-4 py-3">${u.company_name || '—'}</td>
              <td class="px-4 py-3 text-xs">${u.email}<br>${u.phone || ''}</td>
              <td class="px-4 py-3 text-xs">${u.verification_status}</td>
              <td class="px-4 py-3">${u.booking_count}</td>
              <td class="px-4 py-3">
                ${u.is_suspended
                  ? `<button onclick="toggleSuspend('${u.id}', false)" class="text-emerald-600 text-xs font-semibold">Unsuspend</button>`
                  : `<button onclick="toggleSuspend('${u.id}', true)" class="text-red-600 text-xs font-semibold">Suspend</button>`
                }
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (e) {
    document.getElementById('renters-table').innerHTML = `<p class="p-4 text-red-600">${e.message}</p>`;
  }
}

async function toggleSuspend(id, suspend) {
  try {
    await api('/api/admin/users/' + id, {
      method: 'PATCH',
      body: JSON.stringify({ is_suspended: suspend }),
    });
    loadOwners();
    loadRenters();
    alert(suspend ? 'User suspended' : 'User unsuspended');
  } catch (e) {
    alert(e.message);
  }
}

async function setPremium(id, val) {
  try {
    await api('/api/admin/users/' + id, {
      method: 'PATCH',
      body: JSON.stringify({ is_premium: val }),
    });
    loadOwners();
  } catch (e) {
    alert(e.message);
  }
}

async function loadBookings() {
  try {
    const rows = await api('/api/admin/bookings');
    document.getElementById('bookings-table').innerHTML = `
      <table class="w-full text-sm min-w-[900px]">
        <thead class="bg-slate-50 text-left text-xs text-slate-500 uppercase">
          <tr>
            <th class="px-3 py-3">Machine</th>
            <th class="px-3 py-3">Owner</th>
            <th class="px-3 py-3">Renter</th>
            <th class="px-3 py-3">Dates</th>
            <th class="px-3 py-3">Owner Rate</th>
            <th class="px-3 py-3">Commission</th>
            <th class="px-3 py-3">Customer Total</th>
            <th class="px-3 py-3">Status</th>
          </tr>
        </thead>
        <tbody class="divide-y">
          ${rows.map(b => `
            <tr>
              <td class="px-3 py-3 font-medium">${b.machine_name}</td>
              <td class="px-3 py-3 text-xs">${b.owner_name}<br><span class="text-slate-500">${b.owner_company}</span></td>
              <td class="px-3 py-3 text-xs">${b.renter_name}<br><span class="text-slate-500">${b.renter_company}</span></td>
              <td class="px-3 py-3 text-xs">${b.start_date} → ${b.end_date}</td>
              <td class="px-3 py-3 font-mono text-xs">${fmtINR(b.owner_rate)}/d</td>
              <td class="px-3 py-3 text-teal-700 font-semibold">${fmtINR(b.commission_amount)}</td>
              <td class="px-3 py-3 font-bold">${fmtINR(b.total_amount)}</td>
              <td class="px-3 py-3"><span class="text-xs px-2 py-0.5 rounded-full bg-slate-100">${b.status}</span></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (e) {
    document.getElementById('bookings-table').innerHTML = `<p class="p-4 text-red-600">${e.message}</p>`;
  }
}

async function loadAudit() {
  try {
    const rows = await api('/api/admin/audit');
    document.getElementById('audit-table').innerHTML = `
      <table class="w-full text-sm">
        <thead class="bg-slate-50 text-left text-xs text-slate-500 uppercase">
          <tr>
            <th class="px-4 py-3">Time</th>
            <th class="px-4 py-3">Actor</th>
            <th class="px-4 py-3">Action</th>
            <th class="px-4 py-3">Entity</th>
            <th class="px-4 py-3">Details</th>
          </tr>
        </thead>
        <tbody class="divide-y">
          ${rows.map(a => `
            <tr>
              <td class="px-4 py-3 text-xs text-slate-500 whitespace-nowrap">${a.created_at}</td>
              <td class="px-4 py-3 text-xs">${a.actor_name || a.actor_role || '—'}</td>
              <td class="px-4 py-3 font-medium text-xs">${a.action}</td>
              <td class="px-4 py-3 text-xs">${a.entity_type || ''} ${a.entity_id ? a.entity_id.slice(0,8)+'…' : ''}</td>
              <td class="px-4 py-3 text-xs font-mono text-slate-500 max-w-xs truncate">${a.new_value || ''}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  } catch (e) {
    document.getElementById('audit-table').innerHTML = `<p class="p-4 text-red-600">${e.message}</p>`;
  }
}

async function loadSettings() {
  try {
    const s = await api('/api/admin/settings');
    document.getElementById('set-commission').value = s.default_commission_pct || 15;
    document.getElementById('set-name').value = s.platform_name || 'Rentify';
  } catch (e) {
    console.error(e);
  }
}

async function saveSettings() {
  try {
    await api('/api/admin/settings', {
      method: 'PATCH',
      body: JSON.stringify({
        default_commission_pct: document.getElementById('set-commission').value,
        platform_name: document.getElementById('set-name').value,
      }),
    });
    const msg = document.getElementById('settings-msg');
    msg.classList.remove('hidden');
    setTimeout(() => msg.classList.add('hidden'), 3000);
  } catch (e) {
    alert(e.message);
  }
}

// Boot
requireAdmin().then(ok => {
  if (ok !== false) showAdmin('dashboard');
});
