const API = '';
let token = localStorage.getItem('rentify_token');
let user = JSON.parse(localStorage.getItem('rentify_user') || 'null');

function headers() {
  const h = { 'Content-Type': 'application/json' };
  if (token) h['X-Auth-Token'] = token;
  return h;
}

async function api(path, opts = {}) {
  const res = await fetch(API + path, { ...opts, headers: { ...headers(), ...opts.headers } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function showPage(name) {
  document.querySelectorAll('main > section').forEach(s => s.classList.add('hidden'));
  const el = document.getElementById('page-' + name);
  if (el) el.classList.remove('hidden');
  if (name === 'home') doSearch();
  if (name === 'my-bookings') loadBookings();
  if (name === 'owner') loadOwner();
  window.scrollTo(0, 0);
}

function updateNav() {
  const badge = document.getElementById('user-badge');
  const btnLogin = document.getElementById('btn-login');
  const btnLogout = document.getElementById('btn-logout');
  const navBookings = document.getElementById('nav-bookings');
  const navOwner = document.getElementById('nav-owner');
  const navAdmin = document.getElementById('nav-admin');

  if (user) {
    badge.textContent = `${user.full_name} (${user.role})`;
    badge.classList.remove('hidden');
    btnLogin.classList.add('hidden');
    btnLogout.classList.remove('hidden');
    navBookings.style.display = user.role === 'RENTER' || user.role === 'OWNER' ? '' : 'none';
    navOwner.style.display = user.role === 'OWNER' ? '' : 'none';
    navAdmin.style.display = user.role === 'ADMIN' ? '' : 'none';
  } else {
    badge.classList.add('hidden');
    btnLogin.classList.remove('hidden');
    btnLogout.classList.add('hidden');
    navBookings.style.display = 'none';
    navOwner.style.display = 'none';
    navAdmin.style.display = 'none';
  }
}

function fillLogin(email, pass) {
  document.getElementById('login-email').value = email;
  document.getElementById('login-password').value = pass;
}

async function doLogin() {
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  const err = document.getElementById('login-error');
  err.classList.add('hidden');
  try {
    const data = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
    token = data.token;
    user = data.user;
    localStorage.setItem('rentify_token', token);
    localStorage.setItem('rentify_user', JSON.stringify(user));
    updateNav();
    if (user.role === 'ADMIN') window.location.href = '/admin';
    else if (user.role === 'OWNER') showPage('owner');
    else showPage('home');
  } catch (e) {
    err.textContent = e.message;
    err.classList.remove('hidden');
  }
}

function logout() {
  token = null;
  user = null;
  localStorage.removeItem('rentify_token');
  localStorage.removeItem('rentify_user');
  updateNav();
  showPage('home');
}

function fmtINR(n) {
  return '₹' + Number(n).toLocaleString('en-IN');
}

function statusBadge(status, available) {
  if (available) return `<span class="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-full"><span class="status-dot bg-emerald-500"></span>Available</span>`;
  if (status === 'RENTED') return `<span class="inline-flex items-center gap-1.5 text-xs font-semibold text-red-700 bg-red-50 px-2 py-1 rounded-full"><span class="status-dot bg-red-500"></span>Rented</span>`;
  if (status === 'MAINTENANCE') return `<span class="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-1 rounded-full"><span class="status-dot bg-amber-500"></span>Maintenance</span>`;
  return `<span class="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-1 rounded-full"><span class="status-dot bg-slate-400"></span>${status}</span>`;
}

async function doSearch() {
  const q = document.getElementById('search-q').value;
  const days = document.getElementById('search-days').value;
  const start = document.getElementById('search-date').value;
  const sort = document.getElementById('sort-by').value;
  const params = new URLSearchParams({ q, days, start_date: start, sort });
  try {
    const data = await api('/api/machines/search?' + params);
    document.getElementById('result-count').textContent = `(${data.count} machines)`;
    const container = document.getElementById('search-results');
    const empty = document.getElementById('search-empty');
    if (!data.machines.length) {
      container.innerHTML = '';
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');
    container.innerHTML = data.machines.map(m => `
      <div class="bg-white rounded-xl border border-slate-200 overflow-hidden card-hover shadow-sm">
        <div class="relative h-44 bg-slate-100">
          ${m.photo ? `<img src="${m.photo}" alt="${m.name}" class="w-full h-full object-cover" />` : '<div class="w-full h-full flex items-center justify-center text-slate-400">No photo</div>'}
          <span class="absolute top-3 left-3 afi-badge text-white text-[10px] font-bold px-2 py-1 rounded-md tracking-wide">🛡️ AFI PROTECTED</span>
        </div>
        <div class="p-4">
          <div class="flex items-start justify-between gap-2">
            <h3 class="font-bold text-slate-900">${m.name}</h3>
            <span class="font-extrabold text-brand-700 whitespace-nowrap">${fmtINR(m.customer_price_daily)}<span class="text-xs font-normal text-slate-500">/day</span></span>
          </div>
          <p class="text-xs text-slate-500 mt-0.5">${m.brand || ''} ${m.model || ''} · ${m.city}</p>
          <div class="mt-3 flex flex-wrap gap-2">
            ${statusBadge(m.operational_status, m.available_for_period)}
            ${!m.available_for_period && m.next_available ? `<span class="text-xs text-emerald-600 font-medium">Available from ${m.next_available}</span>` : ''}
            ${m.booked_until && !m.available_for_period ? `<span class="text-xs text-red-600">Booked until ${m.booked_until}</span>` : ''}
          </div>
          <div class="mt-3 flex items-center gap-3 text-xs text-slate-600">
            <span>⭐ ${m.rating_avg}</span>
            <span>Reliability ${m.owner_reliability}</span>
            <span>Condition ${m.condition_score}/10</span>
          </div>
          <div class="mt-2 flex gap-3 text-xs">
            ${m.operator_available ? '<span class="text-emerald-600">Operator ✓</span>' : '<span class="text-slate-400">No operator</span>'}
            ${m.transport_available ? '<span class="text-emerald-600">Transport ✓</span>' : '<span class="text-slate-400">No transport</span>'}
          </div>
          <p class="mt-2 text-xs text-slate-400 font-mono">${m.masked_owner}</p>
          <div class="mt-4 flex gap-2">
            <button onclick="viewMachine('${m.id}')" class="flex-1 border border-slate-200 hover:bg-slate-50 py-2 rounded-lg text-sm font-semibold">View Details</button>
            ${m.available_for_period
              ? `<button onclick="bookMachine('${m.id}', '${m.requested_start}', ${m.duration_days}, false)" class="flex-1 bg-brand-600 hover:bg-brand-700 text-white py-2 rounded-lg text-sm font-semibold">Book</button>`
              : m.can_prebook
                ? `<button onclick="bookMachine('${m.id}', '${m.next_available}', ${m.duration_days}, true)" class="flex-1 bg-amber-500 hover:bg-amber-600 text-white py-2 rounded-lg text-sm font-semibold">Pre-Book</button>`
                : `<button disabled class="flex-1 bg-slate-100 text-slate-400 py-2 rounded-lg text-sm font-semibold cursor-not-allowed">Unavailable</button>`
            }
          </div>
        </div>
      </div>
    `).join('');
  } catch (e) {
    console.error(e);
  }
}

async function viewMachine(id) {
  try {
    const m = await api('/api/machines/' + id);
    showPage('detail');
    const pkgs = (m.packages || []).map(p => `
      <div class="border border-slate-200 rounded-lg p-3 text-center">
        <div class="text-xs text-slate-500">${p.label}</div>
        <div class="font-bold text-brand-700">${fmtINR(p.price)}</div>
      </div>
    `).join('');
    const avail = (m.availability || []).map(a => `
      <div class="flex justify-between text-sm py-1 border-b border-slate-100">
        <span>${a.start_date} → ${a.end_date}</span>
        <span class="font-medium ${a.status === 'BOOKED' ? 'text-red-600' : a.status === 'MAINTENANCE' ? 'text-amber-600' : 'text-slate-600'}">${a.status}</span>
      </div>
    `).join('') || '<p class="text-sm text-slate-400">No upcoming blocks</p>';

    const specs = Object.entries(m.specs || {}).map(([k, v]) => `
      <div class="text-sm"><span class="text-slate-500">${k.replace(/_/g, ' ')}:</span> <strong>${v}</strong></div>
    `).join('');

    document.getElementById('detail-content').innerHTML = `
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <div class="rounded-xl overflow-hidden bg-slate-100 h-72 mb-3">
            ${m.media?.[0]?.public_url ? `<img src="${m.media[0].public_url}" class="w-full h-full object-cover" />` : ''}
          </div>
          <span class="afi-badge text-white text-xs font-bold px-3 py-1.5 rounded-md">🛡️ AFI PROTECTED</span>
        </div>
        <div>
          <h1 class="text-2xl font-extrabold">${m.name}</h1>
          <p class="text-slate-500 text-sm mt-1">${m.brand} ${m.model || ''} · ${m.city}, ${m.state}</p>
          <p class="text-3xl font-extrabold text-brand-700 mt-4">${fmtINR(m.customer_price_daily)}<span class="text-base font-normal text-slate-500">/day</span></p>
          <p class="text-sm text-slate-600 mt-3">${m.public_description || ''}</p>
          <div class="flex flex-wrap gap-3 mt-4 text-sm">
            <span>⭐ ${m.rating_avg} (${m.rating_count})</span>
            <span>Condition ${m.condition_score}/10</span>
            <span>Reliability ${m.owner_reliability}</span>
          </div>
          <p class="mt-3 text-sm font-mono text-slate-400">${m.masked_owner}</p>
          <div class="mt-6">
            <h3 class="font-bold text-sm mb-2">Rental packages</h3>
            <div class="grid grid-cols-3 sm:grid-cols-5 gap-2">${pkgs}</div>
          </div>
          <div class="mt-6">
            <h3 class="font-bold text-sm mb-2">Specifications</h3>
            <div class="grid grid-cols-2 gap-2">${specs}</div>
          </div>
          <div class="mt-6">
            <h3 class="font-bold text-sm mb-2">Availability calendar</h3>
            ${avail}
          </div>
          <button onclick="bookFromDetail('${m.id}')" class="mt-6 w-full bg-brand-600 hover:bg-brand-700 text-white font-semibold py-3 rounded-xl">Book This Machine</button>
        </div>
      </div>
    `;
    window._detailMachine = m;
  } catch (e) {
    alert(e.message);
  }
}

function bookFromDetail(id) {
  const days = document.getElementById('search-days').value || 1;
  const start = document.getElementById('search-date').value || new Date().toISOString().slice(0, 10);
  bookMachine(id, start, days, false);
}

async function bookMachine(machineId, start, days, isPrebook) {
  if (!user) {
    showPage('login');
    alert('Please login as a Renter to book.');
    return;
  }
  if (user.role !== 'RENTER') {
    alert('Only renters can book machines. Login with renter demo account.');
    return;
  }
  if (!confirm(`${isPrebook ? 'Pre-book' : 'Book'} this machine for ${days} day(s) starting ${start}?`)) return;
  try {
    const data = await api('/api/bookings', {
      method: 'POST',
      body: JSON.stringify({ machine_id: machineId, start_date: start, duration_days: days, is_prebook: isPrebook }),
    });
    alert(`✅ ${data.message}\nTotal: ${fmtINR(data.total_amount)}\n${data.start_date} → ${data.end_date}`);
    showPage('my-bookings');
  } catch (e) {
    alert('Booking failed: ' + e.message);
  }
}

async function loadBookings() {
  if (!user) { showPage('login'); return; }
  try {
    const rows = await api('/api/bookings/my');
    const el = document.getElementById('bookings-list');
    if (!rows.length) {
      el.innerHTML = '<p class="text-slate-500">No bookings yet.</p>';
      return;
    }
    el.innerHTML = rows.map(b => `
      <div class="bg-white border border-slate-200 rounded-xl p-4 flex flex-wrap gap-4 items-center">
        ${b.photo ? `<img src="${b.photo}" class="w-20 h-16 object-cover rounded-lg" />` : ''}
        <div class="flex-1 min-w-[180px]">
          <div class="font-bold">${b.machine_name}</div>
          <div class="text-sm text-slate-500">${b.start_date} → ${b.end_date} · ${b.duration_days} days</div>
          <div class="text-xs text-slate-400 font-mono mt-1">${b.masked_owner || b.masked_renter || ''}</div>
        </div>
        <div class="text-right">
          <div class="font-bold text-brand-700">${b.total_amount != null ? fmtINR(b.total_amount) : (b.owner_payable != null ? fmtINR(b.owner_payable) + ' (you earn)' : '')}</div>
          <div class="text-xs mt-1"><span class="px-2 py-0.5 rounded-full bg-slate-100 font-medium">${b.status}</span></div>
          ${b.is_prebook ? '<div class="text-xs text-amber-600 mt-1">Pre-booking</div>' : ''}
        </div>
      </div>
    `).join('');
  } catch (e) {
    document.getElementById('bookings-list').innerHTML = `<p class="text-red-600">${e.message}</p>`;
  }
}

async function loadOwner() {
  if (!user || user.role !== 'OWNER') { showPage('login'); return; }
  try {
    const machines = await api('/api/owner/machines');
    const el = document.getElementById('owner-machines');
    el.innerHTML = machines.map(m => `
      <div class="bg-white border border-slate-200 rounded-xl p-4">
        <div class="flex gap-3">
          ${m.photo ? `<img src="${m.photo}" class="w-24 h-20 object-cover rounded-lg" />` : '<div class="w-24 h-20 bg-slate-100 rounded-lg"></div>'}
          <div class="flex-1">
            <div class="font-bold">${m.name}</div>
            <div class="text-xs text-slate-500">${m.brand || ''} · ${m.city || ''}</div>
            <div class="text-sm mt-1">Your rate: <strong>${fmtINR(m.owner_rate_daily)}/day</strong> (private)</div>
            <div class="text-sm">Customer sees: <strong class="text-brand-700">${fmtINR(m.customer_price_daily)}/day</strong></div>
            <div class="text-xs mt-1">
              Listing: <span class="font-semibold ${m.status === 'APPROVED' ? 'text-emerald-600' : m.status === 'PENDING' ? 'text-amber-600' : 'text-red-600'}">${m.status}</span>
            </div>
          </div>
        </div>
        <div class="mt-4">
          <p class="text-xs font-semibold text-slate-500 mb-2">MACHINE STATUS</p>
          <div class="flex gap-2">
            <button onclick="setMachineStatus('${m.id}','AVAILABLE')" class="flex-1 py-2.5 rounded-lg text-sm font-bold border-2 ${m.operational_status === 'AVAILABLE' ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-slate-200 text-slate-500'}">🟢 AVAILABLE</button>
            <button onclick="setMachineStatus('${m.id}','RENTED')" class="flex-1 py-2.5 rounded-lg text-sm font-bold border-2 ${m.operational_status === 'RENTED' ? 'border-red-500 bg-red-50 text-red-700' : 'border-slate-200 text-slate-500'}">🔴 RENTED</button>
            <button onclick="setMachineStatus('${m.id}','MAINTENANCE')" class="flex-1 py-2.5 rounded-lg text-sm font-bold border-2 ${m.operational_status === 'MAINTENANCE' ? 'border-amber-500 bg-amber-50 text-amber-700' : 'border-slate-200 text-slate-500'}">🟠 MAINTENANCE</button>
          </div>
        </div>
      </div>
    `).join('') || '<p class="text-slate-500">No machines yet. Add one!</p>';

    const bookings = await api('/api/bookings/my');
    document.getElementById('owner-bookings').innerHTML = bookings.map(b => `
      <div class="bg-white border rounded-xl p-4 flex flex-wrap justify-between gap-3 items-center">
        <div>
          <div class="font-bold">${b.machine_name}</div>
          <div class="text-sm text-slate-500">${b.start_date} → ${b.end_date}</div>
          <div class="text-xs font-mono text-slate-400">${b.masked_renter}</div>
        </div>
        <div class="text-right">
          <div class="font-bold">${fmtINR(b.owner_payable)} (you earn)</div>
          <div class="text-xs">${b.status}</div>
          ${b.status === 'ACTIVE' || b.status === 'CONFIRMED' ? `
            <button onclick="confirmReturn('${b.id}')" class="mt-2 text-xs bg-emerald-600 text-white px-3 py-1.5 rounded-lg font-semibold">Confirm Return</button>
          ` : ''}
        </div>
      </div>
    `).join('') || '<p class="text-slate-500 text-sm">No bookings yet.</p>';
  } catch (e) {
    console.error(e);
  }
}

async function setMachineStatus(id, status) {
  try {
    await api('/api/owner/machines/' + id + '/status', {
      method: 'PATCH',
      body: JSON.stringify({ operational_status: status }),
    });
    loadOwner();
  } catch (e) {
    alert(e.message);
  }
}

async function confirmReturn(bookingId) {
  const needs = confirm('Machine returned. Does it need maintenance? (OK = Yes, Cancel = No)');
  try {
    await api('/api/owner/bookings/' + bookingId + '/return', {
      method: 'POST',
      body: JSON.stringify({ returned: true, needs_maintenance: needs }),
    });
    alert('Return confirmed.');
    loadOwner();
  } catch (e) {
    alert(e.message);
  }
}

function showAddMachine() {
  document.getElementById('add-machine-modal').classList.remove('hidden');
}
function hideAddMachine() {
  document.getElementById('add-machine-modal').classList.add('hidden');
}

async function submitMachine() {
  const body = {
    name: document.getElementById('am-name').value,
    brand: document.getElementById('am-brand').value,
    model: document.getElementById('am-model').value,
    owner_rate_daily: parseFloat(document.getElementById('am-rate').value),
    city: document.getElementById('am-city').value,
    description: document.getElementById('am-desc').value,
    operator_available: document.getElementById('am-operator').checked,
    transport_available: document.getElementById('am-transport').checked,
  };
  if (!body.name || !body.owner_rate_daily) {
    alert('Name and rate required');
    return;
  }
  try {
    const data = await api('/api/owner/machines', { method: 'POST', body: JSON.stringify(body) });
    alert(data.message);
    hideAddMachine();
    loadOwner();
  } catch (e) {
    alert(e.message);
  }
}

// Init
(function init() {
  const dateInput = document.getElementById('search-date');
  if (dateInput && !dateInput.value) {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    dateInput.value = d.toISOString().slice(0, 10);
  }
  updateNav();
  if (user?.role === 'OWNER') showPage('owner');
  else if (user?.role === 'ADMIN') window.location.href = '/admin';
  else showPage('home');
})();
