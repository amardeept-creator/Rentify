-- Demo seed data for Rentify D1
-- Fixed UUIDs for predictable demos

INSERT OR IGNORE INTO users (id, role, full_name, email, phone, password_hash, company_name, city, state, pin_code, address, verification_status, is_premium, reliability_score) VALUES
('admin-001', 'ADMIN', 'Rentify Admin', 'admin@rentify.in', '9999999999', 'admin123', 'Rentify Platform', 'Mumbai', 'Maharashtra', '400001', 'Platform HQ', 'Fully verified', 1, 100),
('owner-001', 'OWNER', 'Rajesh Kumar', 'rajesh@pavaki.in', '9876543210', 'owner123', 'PAVAKI INFRASOLUTION LLP', 'Lucknow', 'Uttar Pradesh', '226001', 'Industrial Area, Lucknow', 'Fully verified', 1, 92),
('owner-002', 'OWNER', 'Suresh Patel', 'suresh@earthmovers.in', '9876501234', 'owner123', 'EARTH MOVERS INDIA PVT LTD', 'Ahmedabad', 'Gujarat', '380001', 'GIDC Estate', 'Business verified', 0, 88),
('owner-003', 'OWNER', 'Amit Singh', 'amit@cranehire.in', '9988776655', 'owner123', 'SINGH CRANE HIRE', 'Delhi', 'Delhi', '110001', 'Okhla Phase 2', 'Fully verified', 1, 95),
('renter-001', 'RENTER', 'Priya Sharma', 'priya@abcinfra.in', '9123456780', 'renter123', 'ABC INFRASTRUCTURE PRIVATE LIMITED', 'Lucknow', 'Uttar Pradesh', '226010', 'Gomti Nagar', 'Fully verified', 1, 90),
('renter-002', 'RENTER', 'Vikram Mehta', 'vikram@buildco.in', '9111223344', 'renter123', 'BUILDCO CONSTRUCTIONS', 'Mumbai', 'Maharashtra', '400050', 'Andheri East', 'Phone verified', 0, 85);

INSERT OR IGNORE INTO categories (id, name, slug) VALUES
('cat-jcb', 'JCB / Backhoe', 'jcb'),
('cat-exc', 'Excavator', 'excavator'),
('cat-crane', 'Crane', 'crane'),
('cat-bulldozer', 'Bulldozer', 'bulldozer'),
('cat-loader', 'Loader', 'loader'),
('cat-roller', 'Road Roller', 'road-roller'),
('cat-mixer', 'Concrete Mixer', 'concrete-mixer'),
('cat-generator', 'Generator', 'generator'),
('cat-compactor', 'Compactor', 'compactor'),
('cat-pump', 'Pump', 'pump');

INSERT OR IGNORE INTO machines (id, owner_id, category_id, name, brand, model, manufacturing_year, description, public_description, owner_rate_daily, platform_commission_pct, customer_price_daily, status, operational_status, condition_score, city, state, approx_lat, approx_lng, operator_available, transport_available, specs_json, rating_avg, rating_count) VALUES
('mach-001', 'owner-001', 'cat-jcb', 'JCB 3DX', 'JCB', '3DX', 2021, 'Reliable JCB 3DX backhoe loader.', 'JCB 3DX Backhoe Loader – excellent condition, operator available on request.', 8000, 15, 9200, 'APPROVED', 'AVAILABLE', 8.7, 'Lucknow', 'Uttar Pradesh', 26.8467, 80.9462, 1, 1, '{"engine_power":"74 HP","bucket_capacity":"1.1 m³","operating_weight":"7800 kg","fuel":"Diesel"}', 4.6, 18),
('mach-002', 'owner-001', 'cat-exc', '20T Excavator', 'Hyundai', 'R220LC-9S', 2020, 'Hyundai 20 ton excavator.', '20 Ton Excavator – Hyundai R220LC. Strong digging performance.', 12000, 15, 13800, 'APPROVED', 'RENTED', 9.0, 'Lucknow', 'Uttar Pradesh', 26.85, 80.95, 1, 1, '{"operating_weight":"22000 kg","bucket_capacity":"1.05 m³","digging_depth":"6.7 m","fuel":"Diesel"}', 4.8, 12),
('mach-003', 'owner-002', 'cat-crane', '25T Mobile Crane', 'ACE', 'FX 150', 2019, 'ACE mobile crane 25 ton.', '25 Ton Mobile Crane – ACE. Ideal for construction lifting.', 15000, 12, 16800, 'APPROVED', 'AVAILABLE', 8.2, 'Ahmedabad', 'Gujarat', 23.0225, 72.5714, 1, 0, '{"max_lifting":"25 T","boom_length":"30 m","fuel":"Diesel"}', 4.4, 9),
('mach-004', 'owner-003', 'cat-crane', '50T Crawler Crane', 'Kobelco', 'CKE800', 2018, 'Heavy duty crawler crane.', '50 Ton Crawler Crane – Kobelco. For heavy infrastructure work.', 35000, 10, 38500, 'APPROVED', 'AVAILABLE', 8.9, 'Delhi', 'Delhi', 28.6139, 77.2090, 1, 1, '{"max_lifting":"50 T","boom_length":"45 m","fuel":"Diesel"}', 4.7, 15),
('mach-005', 'owner-002', 'cat-roller', 'Road Roller 10T', 'Dynapac', 'CA250', 2021, 'Soil compactor road roller.', '10 Ton Road Roller – Dynapac. Smooth compaction.', 5500, 15, 6325, 'APPROVED', 'AVAILABLE', 8.5, 'Ahmedabad', 'Gujarat', 23.03, 72.58, 0, 1, '{"operating_weight":"10000 kg","drum_width":"2.1 m","fuel":"Diesel"}', 4.5, 7),
('mach-006', 'owner-001', 'cat-mixer', 'Concrete Mixer 1 bag', 'Local', 'CM-1B', 2022, 'Portable 1 bag concrete mixer.', '1 Bag Concrete Mixer – portable and reliable.', 1200, 20, 1440, 'APPROVED', 'AVAILABLE', 7.8, 'Lucknow', 'Uttar Pradesh', 26.84, 80.94, 0, 1, '{"capacity":"1 bag","power":"Electric/Diesel"}', 4.2, 5),
('mach-007', 'owner-003', 'cat-generator', '62.5 kVA Generator', 'Kirloskar', 'KG1-62.5', 2020, 'Silent DG set.', '62.5 kVA Silent Generator – Kirloskar.', 4500, 15, 5175, 'APPROVED', 'MAINTENANCE', 8.0, 'Delhi', 'Delhi', 28.62, 77.21, 0, 1, '{"capacity":"62.5 kVA","fuel":"Diesel","type":"Silent"}', 4.3, 8),
('mach-008', 'owner-002', 'cat-jcb', 'JCB 3DX Super', 'JCB', '3DX Super', 2022, 'Latest model JCB, pending approval.', NULL, 9500, 15, 10925, 'PENDING', 'AVAILABLE', 9.2, 'Ahmedabad', 'Gujarat', 23.04, 72.57, 1, 1, '{"engine_power":"76 HP","bucket_capacity":"1.2 m³","fuel":"Diesel"}', 0, 0);

INSERT OR IGNORE INTO machine_media (id, machine_id, type, original_url, public_url, is_approved, is_primary) VALUES
('media-001', 'mach-001', 'image', 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800', 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800', 1, 1),
('media-002', 'mach-002', 'image', 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800', 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=800', 1, 1),
('media-003', 'mach-003', 'image', 'https://images.unsplash.com/photo-1590856029826-c7a7319b6b0d?w=800', 'https://images.unsplash.com/photo-1590856029826-c7a7319b6b0d?w=800', 1, 1),
('media-004', 'mach-004', 'image', 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=800', 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=800', 1, 1),
('media-005', 'mach-005', 'image', 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800', 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800', 1, 1),
('media-006', 'mach-006', 'image', 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=800', 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=800', 1, 1),
('media-007', 'mach-007', 'image', 'https://images.unsplash.com/photo-1621905251189-08b45d6a809b?w=800', 'https://images.unsplash.com/photo-1621905251189-08b45d6a809b?w=800', 1, 1),
('media-008', 'mach-008', 'image', 'https://images.unsplash.com/photo-1513828583688-c526614334a3?w=800', NULL, 0, 1);

INSERT OR IGNORE INTO bookings (id, machine_id, renter_id, start_date, end_date, duration_days, owner_rate, commission_amount, customer_price, total_amount, owner_payable, status) VALUES
('book-001', 'mach-002', 'renter-001', date('now', '-2 days'), date('now', '+5 days'), 7, 12000, 1800, 13800, 96600, 84000, 'ACTIVE');

INSERT OR IGNORE INTO availability (id, machine_id, start_date, end_date, status, source, booking_id) VALUES
('avail-001', 'mach-002', date('now', '-2 days'), date('now', '+5 days'), 'BOOKED', 'platform', 'book-001'),
('avail-002', 'mach-007', date('now', '-1 days'), date('now', '+3 days'), 'MAINTENANCE', 'owner', NULL);

INSERT OR IGNORE INTO settings (key, value) VALUES
('default_commission_pct', '15'),
('platform_name', 'Rentify'),
('identity_require_premium_both', 'true'),
('masking_enabled', 'true');
