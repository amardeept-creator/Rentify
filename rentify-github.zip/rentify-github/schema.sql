-- Rentify D1 schema
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  role TEXT NOT NULL CHECK(role IN ('OWNER','RENTER','ADMIN')),
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  password_hash TEXT NOT NULL,
  company_name TEXT,
  city TEXT,
  state TEXT,
  pin_code TEXT,
  address TEXT,
  verification_status TEXT DEFAULT 'Unverified',
  is_premium INTEGER DEFAULT 0,
  reliability_score REAL DEFAULT 80,
  is_suspended INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS machines (
  id TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL REFERENCES users(id),
  category_id TEXT REFERENCES categories(id),
  name TEXT NOT NULL,
  brand TEXT,
  model TEXT,
  manufacturing_year INTEGER,
  description TEXT,
  public_description TEXT,
  owner_rate_daily REAL NOT NULL,
  platform_commission_pct REAL DEFAULT 15,
  customer_price_daily REAL,
  status TEXT DEFAULT 'PENDING' CHECK(status IN ('PENDING','APPROVED','REJECTED','SUSPENDED')),
  operational_status TEXT DEFAULT 'AVAILABLE' CHECK(operational_status IN ('AVAILABLE','RENTED','MAINTENANCE')),
  condition_score REAL DEFAULT 8.0,
  city TEXT,
  state TEXT,
  approx_lat REAL,
  approx_lng REAL,
  operator_available INTEGER DEFAULT 0,
  transport_available INTEGER DEFAULT 0,
  specs_json TEXT DEFAULT '{}',
  rating_avg REAL DEFAULT 0,
  rating_count INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS machine_media (
  id TEXT PRIMARY KEY,
  machine_id TEXT NOT NULL REFERENCES machines(id) ON DELETE CASCADE,
  type TEXT DEFAULT 'image',
  original_url TEXT,
  public_url TEXT,
  is_approved INTEGER DEFAULT 0,
  is_primary INTEGER DEFAULT 0,
  admin_notes TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS availability (
  id TEXT PRIMARY KEY,
  machine_id TEXT NOT NULL REFERENCES machines(id) ON DELETE CASCADE,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('BOOKED','EXTERNAL','MAINTENANCE','ADMIN_BLOCK')),
  source TEXT,
  booking_id TEXT,
  reason TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS bookings (
  id TEXT PRIMARY KEY,
  machine_id TEXT NOT NULL REFERENCES machines(id),
  renter_id TEXT NOT NULL REFERENCES users(id),
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  duration_days INTEGER NOT NULL,
  owner_rate REAL NOT NULL,
  commission_amount REAL NOT NULL,
  customer_price REAL NOT NULL,
  transport_cost REAL DEFAULT 0,
  operator_cost REAL DEFAULT 0,
  total_amount REAL NOT NULL,
  owner_payable REAL NOT NULL,
  status TEXT DEFAULT 'PENDING',
  is_prebook INTEGER DEFAULT 0,
  identity_revealed INTEGER DEFAULT 0,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT,
  actor_role TEXT,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  previous_value TEXT,
  new_value TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL,
  full_name TEXT,
  email TEXT,
  company_name TEXT,
  is_premium INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  expires_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_machines_status ON machines(status, operational_status);
CREATE INDEX IF NOT EXISTS idx_machines_owner ON machines(owner_id);
CREATE INDEX IF NOT EXISTS idx_availability_machine ON availability(machine_id, start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_bookings_machine ON bookings(machine_id, start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token);
