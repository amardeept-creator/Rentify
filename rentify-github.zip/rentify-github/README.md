# Rentify

Privacy-first **construction machinery rental** marketplace for India.  
Deploy on **Cloudflare Workers + D1**. Connect this repo to Cloudflare via GitHub.

- Main app + separate admin panel  
- Admin changes reflect immediately on the live app  
- Identity masking, platform pricing, availability, bookings  

---

## Option A — Cloudflare Git integration (recommended)

1. **Create GitHub repo** and push this project (see below).
2. Cloudflare Dashboard → **Workers & Pages** → **Create** → **Import a repository**.
3. Select your GitHub repo → Deploy as **Worker**.
4. Create D1 database and bind it (steps in “First-time setup”).

Or use **Workers → Settings → Builds** / Git-connected deploy if available on your account.

---

## Option B — Push to GitHub, then deploy with CLI

### 1. Upload to GitHub

```bash
unzip rentify-github.zip
cd rentify-github

git init
git add .
git commit -m "Rentify – Cloudflare Workers + D1"

# Create empty repo on GitHub, then:
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/rentify.git
git push -u origin main
```

### 2. First-time Cloudflare setup (once)

```bash
npm install
npx wrangler login
npx wrangler d1 create rentify-db
```

Copy `database_id` into `wrangler.toml`:

```toml
[[d1_databases]]
binding = "DB"
database_name = "rentify-db"
database_id = "paste-your-id-here"
```

Commit and push the updated `wrangler.toml`, then:

```bash
npx wrangler d1 execute rentify-db --remote --file=./schema.sql
npx wrangler d1 execute rentify-db --remote --file=./seed.sql
npx wrangler deploy
```

### 3. Auto-deploy on every push (optional)

1. Cloudflare Dashboard → **My Profile** → **API Tokens** → Create token  
   (template: “Edit Cloudflare Workers”).
2. GitHub repo → **Settings** → **Secrets and variables** → **Actions**:
   - `CLOUDFLARE_API_TOKEN`
   - `CLOUDFLARE_ACCOUNT_ID` (Dashboard → right sidebar)
3. Push to `main` → workflow deploys automatically.

---

## URLs after deploy

| | |
|--|--|
| Main app | `https://rentify.<your-subdomain>.workers.dev/` |
| Admin | `https://rentify.<your-subdomain>.workers.dev/admin/` |

Custom domain: Workers → rentify → Settings → Domains.

---

## Demo logins

| Role | Email | Password |
|------|--------|----------|
| **Admin** | admin@rentify.in | admin123 |
| **Owner** | rajesh@pavaki.in | owner123 |
| **Renter** | priya@abcinfra.in | renter123 |

---

## Local test

```bash
npx wrangler d1 execute rentify-db --local --file=./schema.sql
npx wrangler d1 execute rentify-db --local --file=./seed.sql
npx wrangler dev
```

Open http://localhost:8787

---

## Project structure

```
rentify-github/
├── src/index.js          # Worker API (all backend)
├── public/               # Main app + Admin UI
│   ├── index.html
│   ├── js/app.js
│   └── admin/
├── schema.sql            # D1 tables
├── seed.sql              # Demo data
├── wrangler.toml         # Cloudflare config
├── package.json
└── .github/workflows/    # Optional auto-deploy
```

---

## What works

- Search machinery (name + days + date)
- Availability / pre-book
- Platform commission pricing (owner rate hidden)
- Identity masking
- Owner dashboard + status (Available / Rented / Maintenance)
- Admin: approve machines, change price, suspend users
- Shared D1 → admin edits show on main app instantly
